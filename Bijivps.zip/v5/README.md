# INSTAL SCRIPT
<pre><code>wget https://raw.githubusercontent.com/R2GANTENG/Bijivps/main/setup.sh && chmod +x setup.sh && ./setup.sh</code></pre>
